[hr]
[center][color=teal][size=16pt][b]Auto [iurl] For Internal Links And "nofollow" For External Links[/b][/size][/color]
[u](For SMF 2.0.x)[/u]
Mod by xPandax | [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=158159]Other Mods[/url] by xPandax
[/center]
[hr]
[center][url=http://custom.simplemachines.org/mods/index.php?mod=3767]Link to Mod[/url] | [url]Support Thread for this Mod[/url][/center]


[color=purple][size=12pt][b]Features[/b][/size][/color]
This mod differentiates the internal links from external links and
[list]
[li]automatically adds [color=blue]"iurl"[/color] tag for internal links, so that internal links are opened in the same window[/li]
[li]automatically adds [color=red]"nofollow"[/color] only for external links[/li]
[/list]

[color=purple][size=12pt][b]How-To[/b][/size][/color]
NA.


[color=purple][size=12pt][b]Supported Themes[/b][/size][/color]
Works on all the themes without any custom edits!


[color=purple][size=12pt][b]Supported SMF Versions[/b][/size][/color]
Tested on fresh installation of 2.0.4.


[color=purple][size=12pt][b]Supported Languages[/b][/size][/color]
NA.


[color=purple][size=12pt][b]Support[/b][/size][/color]
If you need support with this mod, please use the [url]Support Thread for this Mod[/url].

 
[color=purple][size=12pt][b]Changelog[/b][/size][/color]
[b]v1.0[/b] - Initial release.


[hr]
[center]
[url=http://creativecommons.org/licenses/by-sa/3.0/deed.en_US][img]http://i.creativecommons.org/l/by-sa/3.0/88x31.png[/img][/url]
This work is licensed under a [url=http://creativecommons.org/licenses/by-sa/3.0/deed.en_US]Creative Commons Attribution-ShareAlike 3.0 Unported License[/url].
[/center]
